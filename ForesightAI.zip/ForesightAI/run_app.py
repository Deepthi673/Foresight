import subprocess
import sys
import os

BASE_DIR = os.path.dirname(__file__)

def main():
    backend_cmd = [sys.executable, os.path.join(BASE_DIR, "backend", "run_backend.py")]
    frontend_cmd = [sys.executable, os.path.join(BASE_DIR, "run_frontend.py")]

    backend_proc = subprocess.Popen(backend_cmd)
    frontend_proc = subprocess.Popen(frontend_cmd)

    print("Backend running on http://127.0.0.1:8000")
    print("Frontend running on http://127.0.0.1:8080")
    print("Press Ctrl+C to stop.")

    try:
        backend_proc.wait()
        frontend_proc.wait()
    except KeyboardInterrupt:
        backend_proc.terminate()
        frontend_proc.terminate()

if __name__ == "__main__":
    main()
