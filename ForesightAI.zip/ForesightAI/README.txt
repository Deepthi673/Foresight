Foresight AI – Groq-powered RAG Agent
=====================================

How to run (desktop):

1. Create a virtual env (optional but recommended)
   python -m venv venv
   venv\Scripts\activate   (Windows)
   source venv/bin/activate  (Linux/Mac)

2. Install backend requirements:
   cd backend
   pip install -r requirements.txt

3. Create a .env file inside backend/ (same folder as requirements.txt):
   Copy .env.example to .env and paste your real GROQ_API_KEY value.

4. Start both backend and frontend from project root:
   cd ..   (go back to project root, where run_app.py is)
   python run_app.py

Then open http://127.0.0.1:8080 in your browser.

This UI is responsive and works on both desktop and mobile browsers.
