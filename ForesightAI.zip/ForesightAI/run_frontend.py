import http.server
import socketserver
import os

PORT = 8080

if __name__ == "__main__":
    web_dir = os.path.join(os.path.dirname(__file__), "frontend")
    os.chdir(web_dir)
    handler = http.server.SimpleHTTPRequestHandler
    with socketserver.TCPServer(("", PORT), handler) as httpd:
        print(f"Serving frontend at http://localhost:{PORT}")
        httpd.serve_forever()
